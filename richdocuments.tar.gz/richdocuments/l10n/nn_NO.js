OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "Lagra",
    "File is too big" : "Fila er for stor",
    "Invalid file provided" : "Ugyldig fil",
    "Select groups" : "Vel grupper",
    "Description" : "Skildring",
    "Error" : "Feil",
    "Nickname" : "Kallenamn",
    "Cancel" : "Avbryt",
    "Save" : "Lagra",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detaljar",
    "Download" : "Last ned",
    "Create" : "Lag"
},
"nplurals=2; plural=(n != 1);");
