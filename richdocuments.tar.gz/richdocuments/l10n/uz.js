OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "Saqlangan",
    "File is too big" : "Fayl juda katta",
    "Invalid file provided" : "Berilgan fayl noto'g'ri",
    "Error" : "Xato",
    "Cancel" : "Bekor qilish",
    "Save" : "Saqlash",
    "Saving…" : "Saqlanmoqda...",
    "Download" : "Yuklab oling"
},
"nplurals=1; plural=0;");
