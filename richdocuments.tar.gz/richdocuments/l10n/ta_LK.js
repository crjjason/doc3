OC.L10N.register(
    "richdocuments",
    {
    "Description" : "விவரிப்பு",
    "Error" : "வழு",
    "Nickname" : "பட்டப்பெயர்",
    "Cancel" : "இரத்து செய்க",
    "Save" : "சேமிக்க ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "விவரங்கள்",
    "Download" : "பதிவிறக்குக",
    "Create" : "உருவாக்குக"
},
"nplurals=2; plural=(n != 1);");
