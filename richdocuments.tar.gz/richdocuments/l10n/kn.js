OC.L10N.register(
    "richdocuments",
    {
    "Can't create document" : "ದಾಖಲೆಯನ್ನು ಸೃಷ್ಟಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ",
    "Saved" : "﻿ಉಳಿಸಿದ",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Cancel" : "﻿ರದ್ದು",
    "Save" : "﻿ಉಳಿಸಿ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "ಪ್ರತಿಯನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಉಳಿಸಿಕೊಳ್ಳಿ",
    "Could not create file" : "﻿ಕಡತ ರಚಿಸಲಾಗಲಿಲ್ಲ",
    "Create" : "ಸೃಷ್ಟಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
