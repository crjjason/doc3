OC.L10N.register(
    "richdocuments",
    {
    "Can't create document" : "Nemoguće kreirati dokument",
    "Saved" : "Spremljeno",
    "Description" : "Opis",
    "Error" : "Greška",
    "Nickname" : "Nadimak",
    "Cancel" : "Otkaži",
    "Save" : "Spremi",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "Preuzmi",
    "Could not create file" : "Datoteku nije moguće kreirati",
    "Create" : "Ustvari"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
