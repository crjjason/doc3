OC.L10N.register(
    "richdocuments",
    {
    "Description" : "Opis",
    "No results" : "Nema rezultata",
    "Error" : "Greška",
    "Cancel" : "Cancel",
    "Save" : "Save",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detalji",
    "Download" : "Preuzmi",
    "Guest" : "Gost",
    "Create" : "Napravi",
    "Select template" : "Odaberite šablon"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
