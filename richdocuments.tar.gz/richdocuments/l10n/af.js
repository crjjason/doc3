OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "Bewaar",
    "File is too big" : "Lêer is te groot",
    "Invalid file provided" : "Ongeldige lêer verskaf",
    "Advanced settings" : "Gevorderde instellings",
    "Description" : "Beskrywing",
    "Error" : "Fout",
    "An error occurred" : "'n Fout het voorgekom",
    "Nickname" : "Bynaam",
    "Cancel" : "Kanselleer",
    "Save" : "Stoor",
    "Saving…" : "Bewaar…",
    "Remove from favorites" : "Verwyder uit gunstelinge",
    "Add to favorites" : "Voeg by gunstelinge",
    "Details" : "Besonderhede",
    "Download" : "Laai af",
    "Create" : "Skep"
},
"nplurals=2; plural=(n != 1);");
