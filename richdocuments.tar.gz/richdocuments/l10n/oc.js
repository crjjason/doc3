OC.L10N.register(
    "richdocuments",
    {
    "Collabora Online" : "Collabora en linha",
    "Can't create document" : "Impossible de crear lo document",
    "New Document.odt" : "Document Novèl.odt",
    "Saved" : "Enregistrat",
    "Advanced settings" : "Paramètres avançats",
    "Description" : "Descripcion",
    "Error" : "Error",
    "Nickname" : "Escais",
    "Cancel" : "Anullar",
    "Save" : "Enregistrar",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detalhs",
    "Download" : "Telecargar",
    "Could not create file" : "Impossible de crear lo fichièr",
    "Create" : "Crear"
},
"nplurals=2; plural=(n > 1);");
