OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "បាន​រក្សាទុក",
    "Description" : "ការ​អធិប្បាយ",
    "Error" : "កំហុស",
    "Cancel" : "បោះបង់",
    "Save" : "រក្សាទុក",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "ព័ត៌មាន​លម្អិត",
    "Download" : "ទាញយក",
    "Create" : "បង្កើត"
},
"nplurals=1; plural=0;");
