OC.L10N.register(
    "richdocuments",
    {
    "Description" : "Keterangan",
    "Error" : "Ralat",
    "Nickname" : "Nama Samaran",
    "Cancel" : "Batal",
    "Save" : "Simpan",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "Muat turun",
    "Create" : "Buat"
},
"nplurals=1; plural=0;");
