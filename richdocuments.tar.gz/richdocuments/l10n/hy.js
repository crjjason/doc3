OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "Պահված",
    "Description" : "Նկարագրություն",
    "Error" : "Սխալ",
    "Nickname" : "Մականուն",
    "Cancel" : "ընդհատել",
    "Save" : "Պահել",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Մանրամասներ",
    "Download" : "Ներբեռնել",
    "Could not create file" : "Չկարողացա ստեղծել ֆայլը",
    "Create" : "Ստեղծել"
},
"nplurals=2; plural=(n != 1);");
