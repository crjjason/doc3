OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "已儲存",
    "Select groups" : "選擇群組",
    "Description" : "描述",
    "Error" : "錯誤",
    "Nickname" : "暱稱",
    "Cancel" : "取消",
    "Save" : "儲存",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "下載",
    "Create" : "新增"
},
"nplurals=1; plural=0;");
