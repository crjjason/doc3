OC.L10N.register(
    "richdocuments",
    {
    "Can't create document" : "ডকুমেন্ট তৈরী করা যাবেনা",
    "Saved" : "সংরক্ষণ করা হলো",
    "File is too big" : "ফাইল খুব বড়",
    "Select groups" : "গ্রুপ নির্ধারণ",
    "Description" : "বিবরণ",
    "Error" : "সমস্যা",
    "Nickname" : "ছদ্মনাম",
    "Cancel" : "বাতির",
    "Save" : "সংরক্ষণ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "বিসতারিত",
    "Download" : "ডাউনলোড",
    "Create" : "তৈরী কর"
},
"nplurals=2; plural=(n != 1);");
