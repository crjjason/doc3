OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "Wedi'u cadw",
    "Description" : "Disgrifiad",
    "No results" : "Dim canlyniadau",
    "Error" : "Gwall",
    "An error occurred" : "Digwyddodd gwall",
    "Nickname" : "Llysenw",
    "Cancel" : "Diddymu",
    "Save" : "Cadw",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Manylion",
    "Download" : "Llwytho i lawr",
    "Create" : "Creu"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
