OC.L10N.register(
    "richdocuments",
    {
    "Description" : "تصریح",
    "Error" : "ایرر",
    "Cancel" : "منسوخ کریں",
    "Save" : "حفظ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "ڈاؤن لوڈ"
},
"nplurals=2; plural=(n != 1);");
