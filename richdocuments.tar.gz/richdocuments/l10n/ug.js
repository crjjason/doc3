OC.L10N.register(
    "richdocuments",
    {
    "Description" : "چۈشەندۈرۈش",
    "Error" : "خاتالىق",
    "Nickname" : "تەخەللۇس",
    "Cancel" : "ۋاز كەچ",
    "Save" : "ساقلا",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "چۈشۈر",
    "Create" : "قۇر"
},
"nplurals=2; plural=(n != 1);");
