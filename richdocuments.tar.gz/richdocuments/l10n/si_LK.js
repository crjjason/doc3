OC.L10N.register(
    "richdocuments",
    {
    "File is too big" : "ගොනුව විශාල වැඩියි",
    "Invalid file provided" : "ඔබ තේරූ ගොනුව වැරදි",
    "Description" : "විස්තරය",
    "Error" : "දෝෂයක්",
    "Nickname" : "පටබැඳි නම",
    "Cancel" : "අවලංගු කරන්න",
    "Save" : "සුරකින්න",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Download" : "බාන්න",
    "Create" : "තනන්න"
},
"nplurals=2; plural=(n != 1);");
