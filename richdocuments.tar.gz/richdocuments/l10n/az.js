OC.L10N.register(
    "richdocuments",
    {
    "Can't create document" : "Sənədi yaratmaq mümkün olmadı",
    "Saved" : "Saxlanıldı",
    "Advanced settings" : "İrəliləmiş quraşdırmalar",
    "Select groups" : "Qrupları seç",
    "Description" : "Açıqlanma",
    "Error" : "Səhv",
    "Cancel" : "Dayandır",
    "Save" : "Saxla",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Detallar",
    "Download" : "Yüklə",
    "Could not create file" : "Faylı yaratmaq olmur",
    "Create" : "Yarat"
},
"nplurals=2; plural=(n != 1);");
