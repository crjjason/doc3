OC.L10N.register(
    "richdocuments",
    {
    "File is too big" : "د فایل وزن ډېر دی",
    "Invalid file provided" : "فایل روغ نه دی",
    "Error" : "شسیب",
    "Cancel" : "پرېښول",
    "Save" : "ساتل",
    "Remove from favorites" : "له نښو ويستل",
    "Add to favorites" : "په نښه کول",
    "Details" : "معلومات",
    "Download" : "ښکته کول"
},
"nplurals=2; plural=(n != 1);");
